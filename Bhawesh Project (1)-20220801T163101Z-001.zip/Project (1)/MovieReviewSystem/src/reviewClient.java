import java.util.List;

public class reviewClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		reviews r;
		
		r=new reviews(1, "3 idiot movie is amazing",1,1);
		ReviewDAO rdao=new ReviewDAO();
		//System.out.println(rdao.insert(r) + " Record Inserted");
		r.setReview("3 Idiots movie is amazing!!");
		System.out.println(rdao.update(r) + " Record Updated");
	//	System.out.println(mdao.delete(m) + " Record deleted");
		List<reviews> reviewList=rdao.read();
		for(reviews r1:reviewList)
			System.out.println(r1.getReview());


	}

}
