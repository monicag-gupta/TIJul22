import java.util.List;
import java.util.Scanner;
public class Client {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Type 1 for new user\nType 2 for existing user\nType 3 to exit");
			System.out.println("User Input:");
			String ip=sc.nextLine();
			if(ip.equals("1"))
			{
				//String waste=sc.nextLine();
				//label1:
				System.out.print("Enter name:");
				String name;
				while((name=sc.nextLine()).isEmpty())
				{System.out.println("Name can't be empty");
				System.out.print("Enter name:"); 
				}		
				System.out.print("Enter email:");
				String email;
				while((email=sc.nextLine()).isEmpty())
				{System.out.println("email can't be empty");
				System.out.print("Enter email:"); 
				}
				System.out.print("Enter password:");
				String pass;
				while((pass=sc.nextLine()).isEmpty())
				{System.out.println("password can't be empty");
				System.out.print("Enter password:"); 
				}
				users u=new users(name,email,pass);
				usersDAO udao=new usersDAO();
				System.out.println(u);
				udao.insert(u);
				System.out.println("New user created!");
				continue;
			}
			else if(ip.equals("2"))
			{
				usersDAO udao=new usersDAO();
				//String waste1=sc.nextLine();
				System.out.println("Enter email ID:");
				String ip1;
				while((ip1=sc.nextLine()).isEmpty())
				{System.out.println("email id can't be empty");
				System.out.print("Enter email ID:"); 
				}
				System.out.println("Enter user password:");
				String ip2;
				while((ip2=sc.nextLine()).isEmpty())
				{System.out.println("password can't be empty");
				System.out.print("Enter password:"); 
				}
				users emps=udao.read(ip1,ip2);
				if(emps==null)
					continue;
				System.out.println("Login Successful!!!");
				System.out.println(emps+"\n");
				while(true){
				System.out.println("Type 1 to add a new movie\nType 2 to edit a movie\nType 3 to add a review\nType 4 to add rating to a movie"
						+"\nType 5 to view movies by genre\nType 6 to view movie details\nType 7 to view top 10 movies overall\nType 8 to view top 10 movies by genre\nType 56 to logout");
				System.out.println("User Input:");
				String i1=sc.nextLine();
				//Add a new movie
				if(i1.equals("1"))
				{
					moviesDAO mdao=new moviesDAO();
					//String waste=sc.nextLine();
					System.out.println("Enter movie_name:");
					String name;
					while((name=sc.nextLine()).isEmpty())
					{System.out.println("name can't be empty");
					System.out.print("Enter movie_name:"); 
					}
					System.out.println("Enter cast:");
					String cast;
					while((cast=sc.nextLine()).isEmpty())
					{System.out.println("cast can't be empty");
					System.out.print("Enter cast:"); 
					}
					System.out.println("Enter summary:");
					String summ;
					while((summ=sc.nextLine()).isEmpty())
					{System.out.println("summary can't be empty");
					System.out.print("Enter summary:"); 
					}
					System.out.println("Enter genre:");
					String gen;
					while((gen=sc.nextLine()).isEmpty())
					{System.out.println("genre can't be empty");
					System.out.print("Enter genre:"); 
					}
					//System.out.println("Enter rating:");
					Float rat=0.0f;
					int id=mdao.id_return(ip1);
					//System.out.println(id);
					movies m=new movies(name,cast,summ,gen,rat,id);
					mdao.insert(m);
					System.out.println("New movie added!");
					continue;
				}
				//Edit a movie
				else if(i1.equals("2"))
				{
					moviesDAO mdao=new moviesDAO();
					//String waste=sc.nextLine();
					System.out.println("Enter movie_name:");
					String name;
					while((name=sc.nextLine()).isEmpty())
					{System.out.println("name can't be empty");
					System.out.print("Enter movie_name:"); 
					}
					System.out.println("Enter cast:");
					String cast;
					while((cast=sc.nextLine()).isEmpty())
					{System.out.println("cast can't be empty");
					System.out.print("Enter cast:"); 
					}
					System.out.println("Enter summary:");
					String summ;
					while((summ=sc.nextLine()).isEmpty())
					{System.out.println("summary can't be empty");
					System.out.print("Enter summary:"); 
					}
					System.out.println("Enter genre:");
					String gen;
					while((gen=sc.nextLine()).isEmpty())
					{System.out.println("genre can't be empty");
					System.out.print("Enter genre:"); 
					}
					//System.out.println("Enter rating:");
					Float rat=mdao.return_rating(name);
					int id=mdao.id_return(ip1);
					//System.out.println(id);
					movies m=new movies(name,cast,summ,gen,rat,id);
					mdao.update(m);
					System.out.println("Movie updated!");
					continue;
				}
				//Add a review
				else if(i1.equals("3"))
				{
					reviewDAO rdao=new reviewDAO();
					//String waste=sc.nextLine();
					System.out.println("Enter movie_name:");
					String name;
					while((name=sc.nextLine()).isEmpty())
					{System.out.println("name can't be empty");
					System.out.print("Enter movie_name:"); 
					}
					System.out.println("Enter review:");
					String rev;
					while((rev=sc.nextLine()).isEmpty())
					{System.out.println("review can't be empty");
					System.out.print("Enter review:"); 
					}
					int id=rdao.id_return(ip1);
					//System.out.println(id);
					int movie_id=rdao.movie_id_return(name);
					review r=new review(id,movie_id,rev);
					rdao.insert(r);
					System.out.println("New review for movie '"+name+"' added!");
					continue;
				}
				//Add rating
				else if(i1.equals("4"))
				{
					ratingDAO rdao=new ratingDAO();
					//String waste=sc.nextLine();
					System.out.println("Enter movie_name:");
					String name;
					while((name=sc.nextLine()).isEmpty())
					{System.out.println("name can't be empty");
					System.out.print("Enter movie_name:"); 
					}
					System.out.println("Enter rating:");
					int rat=sc.nextInt();
					int id=rdao.id_return(ip1);
					//System.out.println(id);
					int movie_id=rdao.movie_id_return(name);
					rating r=new rating(id,movie_id,rat);
					rdao.insert(r);
					System.out.println("New rating for movie '"+name+"' added!");
					continue;
				}
				//View movies by genre
				else if(i1.equals("5"))
				{
					moviesDAO mdao=new moviesDAO();
					//String waste=sc.nextLine();
					System.out.println("Enter genre:");
					String gen;
					while((gen=sc.nextLine()).isEmpty())
					{System.out.println("genre can't be empty");
					System.out.print("Enter genre:"); 
					}
					int id=mdao.id_return(ip1);
					//System.out.println(id);
					//movies m=new movies(name,cast,summ,gen,rat,id);
					System.out.println("Movies in "+gen+" genre are:");
					List<movies> ls=mdao.read(gen);
					System.out.println(ls);
					//mdao.update(m);
					//System.out.println("Movie updated!");
					continue;
				}
				//Search for a movie via movie name
				else if(i1.equals("6"))
				{
					moviesDAO mdao=new moviesDAO();
					//String waste=sc.nextLine();
					System.out.println("Enter movie_name:");
					String name;
					while((name=sc.nextLine()).isEmpty())
					{System.out.println("name can't be empty");
					System.out.print("movie_name password:"); 
					}
					int id=mdao.id_return(ip1);
					//System.out.println(id);
					//movies m=new movies(name,cast,summ,gen,rat,id);
					System.out.println("Details of movie "+name+" are:");
					List<movies> ls=mdao.read_movie(name);
					System.out.println(ls);
					//mdao.update(m);
					//System.out.println("Movie updated!");
					continue;
				}
				//top 10 movies
				else if(i1.equals("7"))
				{
					moviesDAO mdao=new moviesDAO();
					//String waste=sc.nextLine();
					//System.out.println("Enter movie_name:");
					//String name=sc.nextLine();
					int id=mdao.id_return(ip1);
					//System.out.println(id);
					//movies m=new movies(name,cast,summ,gen,rat,id);
					System.out.println("Overall top 10 movies are:");
					List<movies> ls=mdao.read_movietop10();
					System.out.println(ls);
					//mdao.update(m);
					//System.out.println("Movie updated!");
					continue;
				}
				//top 10 movies by genre
				else if(i1.equals("8"))
				{
					moviesDAO mdao=new moviesDAO();
					//String waste=sc.nextLine();
					System.out.println("Enter genre:");
					String gen;
					while((gen=sc.nextLine()).isEmpty())
					{System.out.println("genre can't be empty");
					System.out.print("Enter genre:"); 
					}
					int id=mdao.id_return(ip1);
					//System.out.println(id);
					//movies m=new movies(name,cast,summ,gen,rat,id);
					System.out.println("Top 10 movies of "+gen+" genre are:");
					List<movies> ls=mdao.read_movietop10genre(gen);
					System.out.println(ls);
					//mdao.update(m);
					//System.out.println("Movie updated!");
					continue;
				}
				else if(i1.equals("56"))
				{
					System.out.println("User logged out!\n");
					break;
				}
				else if(i1.isEmpty())
				{
					System.out.println("Invalid Input ");
					continue;
				}
				else
				{
					System.out.println("Invalid Input ");
					continue;
				}
				}
				continue;
			}
			else if(ip.equals("3"))
			{
				System.out.println("Bye!");
				return;
			}
			else if(ip.isEmpty())
			{
				System.out.println("Invalid Input ");
				continue;
			}
			else
			{
				System.out.println("Invalid Input ");
				continue;
			}
		}	
		}
}