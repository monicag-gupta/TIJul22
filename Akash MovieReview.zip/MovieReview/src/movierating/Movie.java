package movierating;

public class Movie {
	int movie_id = 0;
	String movie_name;
	String summary;
	String cast;
	String genre;
	float avg_rating = 0f;
	int user_id;

	public Movie() {
	}

	public Movie(int movie_id, String movie_name, String summary, String cast, String genre, float avg_rating,
			int user_id) {
		super();
		this.movie_id = movie_id;
		this.movie_name = movie_name;
		this.summary = summary;
		this.cast = cast;
		this.genre = genre;
		this.avg_rating = avg_rating;
		this.user_id = user_id;
	}

	public int getMovie_id() {
		return movie_id;
	}

	public void setMovie_id(int movie_id) {
		this.movie_id = movie_id;
	}

	public String getMovie_name() {
		return movie_name;
	}

	public void setMovie_name(String movie_name) {
		this.movie_name = movie_name;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getCast() {
		return cast;
	}

	public void setCast(String cast) {
		this.cast = cast;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public float getAvg_rating() {
		return avg_rating;
	}

	public void setAvg_rating(float avg_rating) {
		this.avg_rating = avg_rating;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	@Override
	public String toString() {
		return "Movie [movie_id=" + movie_id + ", movie_name=" + movie_name + ", summary=" + summary + ", cast=" + cast
				+ ", genre=" + genre + ", avg_rating=" + avg_rating + ", user_id=" + user_id + "]";
	}

}
