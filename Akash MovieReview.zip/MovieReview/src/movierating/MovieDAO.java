package movierating;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class MovieDAO {
	Connection con = null;
	PreparedStatement Pstmt = null;
	Statement statement = null;
	Scanner sc = new Scanner(System.in);

	public void Con() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/movieReview", "root", "root");

	}

	public void insertMovie(Movie m) {
		try {
			Con();
			String sql = "insert into movie(movie_name,summary,cast,genre,avg_rating,user_id) values(?,?,?,?,?,?);";
			Pstmt = con.prepareStatement(sql);
			Pstmt.setString(1, m.getMovie_name());
			Pstmt.setString(2, m.getSummary());
			Pstmt.setString(3, m.getCast());
			Pstmt.setString(4, m.getGenre());
			Pstmt.setFloat(5, m.getAvg_rating());
			Pstmt.setInt(6, m.getUser_id());
			int rowsInserted = Pstmt.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("A new movie inserted successfully!");
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}

	public void readMovie() {
		try {
			Con();
			String sql = "Select m.movie_id,m.movie_name,m.Summary,m.cast,m.Genre ,m.Average_rating,r.review from movie m\n"
					+ "Inner join review r\n" + "On m.user_id=r.user_id;";
			statement = con.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				int moviId = result.getInt(1);
				String movieName = result.getString(2);
				String sumary = result.getString(3);
				String cast = result.getString(4);
				String genre = result.getString(5);
				Float avgRat = result.getFloat(6);
				String review = result.getString(7);

				Float avgRatt = getAvgRating(moviId);
				System.out.println("#" + moviId + "->" + movieName + "," + sumary + "," + cast + "," + genre + ","
						+ avgRatt + "," + review);
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	public void insertReview(Review r) {
		try {
			Con();
			String sql = "insert into review(movie_id,review,user_id) values(?,?,?);";
			Pstmt = con.prepareStatement(sql);
			Pstmt.setInt(1, r.getMovie_id());
			Pstmt.setString(2, r.getReview());
			Pstmt.setInt(3, r.getUser_id());

			int rowsInserted = Pstmt.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("A review inserted successfully!");
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}

	public void insertRating(Rating r) {
		try {
			Con();
			String sql = "insert into rating(movie_id,Rating,user_id) values(?,?,?);";
			Pstmt = con.prepareStatement(sql);
			Pstmt.setInt(1, r.getMovie_id());
			Pstmt.setInt(2, r.getRating());
			Pstmt.setInt(3, r.getUser_id());
			int rowsInserted = Pstmt.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("A rate inserted successfully!");
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}

	public float getAvgRating(int id) {
		float avg = 0;
		try {
			Con();
			String sql = "SELECT AVG(Rating) as avgTotal FROM rating where movie_id = '" + id + "'";
			statement = con.createStatement();
			ResultSet result = statement.executeQuery(sql);
			avg = 0f;
			while (result.next()) {
				avg = result.getFloat("avgTotal");
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}
		return avg;

	}

	public void insertUser(Users u) {
		try {
			Con();
			String sql = "insert into users(user_name,email_id) values(?,?);";
			Pstmt = con.prepareStatement(sql);
			Pstmt.setString(1, u.getUser_name());
			Pstmt.setString(2, u.getEmail_id());
			int rowsInserted = Pstmt.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("A rate inserted successfully!");
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}

	public void getGenre(String gnr) {
		try {
			Con();
			String sql = "Select * from movie where Genre = '" + gnr + "'";
			statement = con.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				int moviId = result.getInt(1);
				String movieName = result.getString(2);
				String sumary = result.getString(3);
				String cast = result.getString(4);
				String genre = result.getString(5);
				Float avgRat = result.getFloat(6);
				String review = result.getString(7);

				Float avgRatt = getAvgRating(moviId);
				System.out.println("#" + moviId + "->" + movieName + "," + sumary + "," + cast + "," + genre + ","
						+ avgRatt + "," + review);
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}

	public void searchMovie(String mv) {
		try {
			Con();
			String sql = "Select * from movie where movie_name = '" + mv + "'";
			statement = con.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				int moviId = result.getInt(1);
				String movieName = result.getString(2);
				String sumary = result.getString(3);
				String cast = result.getString(4);
				String genre = result.getString(5);
				Float avgRat = result.getFloat(6);
				String review = result.getString(7);

				Float avgRatt = getAvgRating(moviId);
				System.out.println("#" + moviId + "->" + movieName + "," + sumary + "," + cast + "," + genre + ","
						+ avgRatt + "," + review);
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}

	public void getTenMovies() {
		System.out.println("top 10 movies start");
		try {
			Con();
			String sql = "select * from movie order by Average_rating desc limit 10;";
			statement = con.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while (result.next()) {
				int moviId = result.getInt(1);
				String movieName = result.getString(2);
				String sumary = result.getString(3);
				String cast = result.getString(4);
				String genre = result.getString(5);
				Float avgRat = result.getFloat(6);
				String review = result.getString(7);

				System.out.println("#" + moviId + "->" + movieName + "," + sumary + "," + cast + "," + genre + ","
						+ avgRat + "," + review);
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}

	public void Update(int mid) {
		try {
			Con();
			System.out.print("\n1.Update Movie Name" + "\n2.Update Summary" + "\n3.Update cast" + "\n4.Update Genre");
			int x1 = sc.nextInt();
			if (x1 == 1) {
				System.out.print("Enter movie name : ");
				String nmeString = sc.nextLine();
				String sql1 = "UPDATE movie SET movie_name= ? WHERE movie_id='" + mid + "'";
				Pstmt = con.prepareStatement(sql1);
				Pstmt.setString(1, nmeString);
			} else if (x1 == 2) {
				System.out.print("Enter new summary : ");
				String cl = sc.nextLine();
				String sql1 = "UPDATE movie SET Summary= ? WHERE movie_id='" + mid + "'";
				Pstmt = con.prepareStatement(sql1);
				Pstmt.setString(1, cl);
			} else if (x1 == 3) {
				System.out.print("Enter cast name : ");
				String scn = sc.nextLine();
				String sql1 = "UPDATE movie SET cast= ? WHERE movie_id='" + mid + "'";
				Pstmt = con.prepareStatement(sql1);
				Pstmt.setString(1, scn);
			} else if (x1 == 4) {
				System.out.print("Enter Genre Name : ");
				String fnme = sc.nextLine();
				String sql1 = "UPDATE movie SET Genre= ? WHERE movie_id='" + mid + "'";
				Pstmt = con.prepareStatement(sql1);
				Pstmt.setString(1, fnme);
			}

			int rowsUpdated = Pstmt.executeUpdate();
			if (rowsUpdated > 0) {
				System.out.println("An existing user was updated successfully!");
			}

		} catch (Exception ex) {
			System.out.println(ex);
		}
		sc.close();
	}

}