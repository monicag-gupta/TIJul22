package movierating;

import java.util.*;

public class MovieMain {
	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		int nu = 1;
		do {
			System.out.println("Welcome to the Movie review App!!\n");
			System.out.println("Press 1 -> To Add new movie");
			System.out.println("Press 2 -> To Edit an existing movie entry");
			System.out.println("Press 3 -> To Add a review to a movie");
			System.out.println("Press 4 -> To Rate a movies");
			System.out.println("Press 5 -> To View a list of movies from a genre");
			System.out.println("Press 6 -> To View a list of top 10 movies overall or from a genre.");
			System.out.println("Press 7 -> To Search a movie by name or/and by genre.");
			System.out.println("Press 8 -> To View details of a movie, see its summary, cast, genre, reviews");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				Movie movie = new Movie();
				System.out.print("Enter a movie name : ");
				String movie_name = sc.next();
				movie.setMovie_name(movie_name);

				System.out.print("Enter summary of movie : ");
				String summary = sc.next();
				movie.setSummary(summary);

				System.out.print("Enter all cast name with space : ");
				String cast = sc.nextLine();
				movie.setCast(cast);

				System.out.print("Enter genre of movie : ");
				String genre = sc.nextLine();
				movie.setGenre(genre);
				System.out.print("Enter user_id : ");
				int userId = sc.nextInt();
				sc.nextLine();
				movie.setUser_id(userId);
				MovieDAO mDao = new MovieDAO();
				mDao.insertMovie(movie);
				break;
			case 2:
				System.out.print("Enter movie id : ");
				int y = sc.nextInt();
				MovieDAO mDao5 = new MovieDAO();
				mDao5.Update(y);
				break;
			case 3:
				System.out.print("Enter user id : ");
				int uuid = sc.nextInt();
				System.out.print("Enter movie_id : ");
				int mmid = sc.nextInt();
				System.out.print("Enter movie name : ");
				String mmn = sc.nextLine();
				System.out.print("Enter Review : ");
				String rvw = sc.nextLine();
				Review review = new Review(0, mmid, uuid, rvw);
				MovieDAO mmDao = new MovieDAO();
				mmDao.insertReview(review);
				break;
			case 4:
				System.out.print("Enter user id : ");
				int uuid1 = sc.nextInt();
				System.out.print("Enter movie_id : ");
				int mmid1 = sc.nextInt();
				System.out.print("Enter movie name : ");
				String mmn1 = sc.nextLine();
				System.out.print("Rate this movie: ");
				int rt1 = sc.nextInt();
				Rating rt = new Rating(0, mmid1, rt1, uuid1);
				MovieDAO mmDao1 = new MovieDAO();
				mmDao1.insertRating(rt);
				break;
			case 5:
				System.out.print("Enter genre of the movie : ");
				String gr = sc.next();
				MovieDAO mmDao2 = new MovieDAO();
				mmDao2.getGenre(gr);
				break;
			case 6:
				MovieDAO mmDao4 = new MovieDAO();
				mmDao4.getTenMovies();
				break;
			case 7:
				System.out.println("/nSearch a movie by name or/and by genre");
				System.out.println("Press 1.Genre \nPress 2.Movie Name");
				int x = sc.nextInt();
				if (x == 1) {
					System.out.print("Enter genre : ");
					String gnr = sc.next();
					MovieDAO mmDao3 = new MovieDAO();
					mmDao3.getGenre(gnr);
				} else {
					System.out.print("Enter Movie Name : ");
					String mvr = sc.nextLine();
					MovieDAO mmDao3 = new MovieDAO();
					mmDao3.searchMovie(mvr);
				}
				break;
			case 8:
				MovieDAO mm = new MovieDAO();
				mm.readMovie();
				break;
			default:
				System.out.println("Invalid Entry");
			}
			System.out.println("\nPress 1 to continue the menu otherwise press 0 for Exit from the App!");
			nu = sc.nextInt();
		} while (nu == 1);
		sc.close();
	}
}
